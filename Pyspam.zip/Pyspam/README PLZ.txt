I am not responsible for the bans or problems this tool may cause.


To send messages you need the id of the chat you are going to spam, and the token of the account sending the messages.
You can find plenty of videos on how to get your accounts token on youtube.


Modify the python script as you please.  


Have a nice day.
--ducksteam--